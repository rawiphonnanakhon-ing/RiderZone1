package com.riderzone.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.location.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {
    private WindowManager wm; private View bubble; private TextView label; private LocationManager lm; private LocationListener listener;
    private static final int NOTIF_ID=77;
    @Override public void onCreate(){ super.onCreate(); createChannel(); startForeground(NOTIF_ID, new Notification.Builder(this,"riderzone").setContentTitle("Rider Zone").setContentText("กำลังตรวจตำแหน่งพื้นที่งาน").setSmallIcon(android.R.drawable.ic_menu_mylocation).build()); showBubble(); startLocation(); }
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("riderzone","Rider Zone",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);} }
    private void showBubble(){ wm=(WindowManager)getSystemService(WINDOW_SERVICE); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(18,10,18,10); box.setBackgroundColor(Color.argb(225,20,30,45)); label=new TextView(this); label.setText("Rider Zone\nกำลังหา GPS…"); label.setTextColor(Color.WHITE); label.setTextSize(12); box.addView(label); bubble=box; int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE; WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,-2); p.gravity=Gravity.TOP|Gravity.END; p.x=12; p.y=80; wm.addView(bubble,p); }
    private void startLocation(){ lm=(LocationManager)getSystemService(LOCATION_SERVICE); listener=new LocationListener(){ public void onLocationChanged(Location l){ String s="📍 GPS "+String.format(java.util.Locale.US,"%.5f, %.5f",l.getLatitude(),l.getLongitude()); label.setText("Rider Zone\n"+s); } public void onProviderEnabled(String p){} public void onProviderDisabled(String p){} public void onStatusChanged(String p,int s,Bundle b){} }; try{ if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return; lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,3000,10,listener); lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,5000,20,listener);}catch(Exception ignored){} }
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    @Override public void onDestroy(){ if(lm!=null&&listener!=null)lm.removeUpdates(listener); if(wm!=null&&bubble!=null)wm.removeView(bubble); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
